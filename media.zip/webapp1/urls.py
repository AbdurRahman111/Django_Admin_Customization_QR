from django.urls import path
from . import views
from django.contrib import admin


urlpatterns = [
    # path('adminpage/login/?next=/adminpage/', views.adminlogin, name="admin"),
    path('admin/', views.adminlogin, name="admin"),
    path('', views.adminlogin, name="admin"),
    path('adminpage/', admin.site.urls),
    path('extranet/services/verificarisultaticandidato.aspx', views.student_page, name="student_page"),
]